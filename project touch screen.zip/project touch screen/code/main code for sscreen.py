from machine import UART, Pin
import time

PIN_DISP_RX = 16
PIN_DISP_TX = 17
PIN_BUZZER = 18
DISP_BAUD = 115200

FONT_TITLE = 5
FONT_TIME = 7
FONT_KEY = 5
FONT_BIG = 6

COL_BLACK, COL_RED, COL_WHITE = 1, 3, 8

KEY_MINUS, KEY_PLUS, KEY_START, KEY_CANCEL, KEY_STOP = 1, 2, 3, 4, 5

ESC, DC1, DC2, ACK, NAK = 0x1B, 0x11, 0x12, 0x06, 0x15

uart = UART(2, baudrate=DISP_BAUD, bits=8, parity=None, stop=1,
            tx=PIN_DISP_TX, rx=PIN_DISP_RX)
buzzer_pin = Pin(PIN_BUZZER, Pin.OUT, value=0)


def buzzer(on):
    buzzer_pin.value(1 if on else 0)


def click_beep():
    buzzer(True)
    time.sleep_ms(30)
    buzzer(False)


def drain():
    while uart.any():
        uart.read()


def read_byte(timeout_ms):
    start = time.ticks_ms()
    while time.ticks_diff(time.ticks_ms(), start) < timeout_ms:
        if uart.any():
            return uart.read(1)[0]
    return -1


class Cmd:
    def __init__(self):
        self.b = bytearray()

    def _esc(self, a, b):
        self.b += bytes([ESC, ord(a), ord(b)])

    def _u16(self, v):
        self.b += bytes([v & 0xFF, (v >> 8) & 0xFF])

    def _str(self, s):
        self.b += s.encode("latin-1") + b"\x00"

    def clear(self):
        self._esc("D", "L")

    def delete_touch_areas(self):
        self._esc("A", "L")
        self.b += bytes([0, 1])

    def font(self, n):
        self._esc("Z", "F")
        self.b.append(n)

    def text_color(self, fg, bg):
        self._esc("F", "Z")
        self.b += bytes([fg, bg])

    def text(self, align, x, y, s):
        self._esc("Z", align)
        self._u16(x)
        self._u16(y)
        self._str(s)

    def key(self, x1, y1, x2, y2, code, label):
        self._esc("A", "T")
        for v in (x1, y1, x2, y2):
            self._u16(v)
        self.b += bytes([code, 0])
        self._str("C" + label)

    def send(self):
        data = bytes(self.b[:255])
        bcc = (DC1 + len(data) + sum(data)) & 0xFF
        packet = bytes([DC1, len(data)]) + data + bytes([bcc])
        for _ in range(3):
            drain()
            uart.write(packet)
            start = time.ticks_ms()
            while time.ticks_diff(time.ticks_ms(), start) < 200:
                if uart.any():
                    c = uart.read(1)[0]
                    if c == ACK:
                        return True
                    if c == NAK:
                        break
        print("Display did not ACK - check wiring, baud rate, TX/RX")
        return False


def poll_touch():
    drain()
    uart.write(bytes([DC2, 0x01, ord("S"), (DC2 + 0x01 + ord("S")) & 0xFF]))

    if read_byte(50) != ACK:
        return 0
    if read_byte(30) != DC1:
        return 0

    n = read_byte(30)
    if n < 0:
        return 0

    data = bytearray()
    for _ in range(n):
        c = read_byte(30)
        if c < 0:
            return 0
        data.append(c)

    rx_bcc = read_byte(30)
    if rx_bcc != (DC1 + n + sum(data)) & 0xFF:
        return 0

    for i in range(len(data) - 3):
        if data[i] == ESC and data[i + 1] == ord("A") and data[i + 2] == 1:
            return data[i + 3]
    return 0


SETUP, RUNNING, RINGING = 0, 1, 2
state = SETUP
set_minutes = 5
end_at = 0
shown_secs = -1
ring_start = 0


def draw_time(secs):
    c = Cmd()
    c.font(FONT_TIME)
    c.text("C", 240, 70, "%02d:%02d" % (secs // 60, secs % 60))
    c.send()


def show_setup():
    global state
    state = SETUP
    c = Cmd()
    c.delete_touch_areas()
    c.clear()
    c.text_color(COL_WHITE, COL_BLACK)
    c.font(FONT_TITLE)
    c.text("C", 240, 15, "ALARM TIMER")
    c.send()

    draw_time(set_minutes * 60)

    c = Cmd()
    c.font(FONT_KEY)
    c.key(20, 190, 150, 255, KEY_MINUS, "-1 MIN")
    c.key(165, 190, 315, 255, KEY_START, "START")
    c.key(330, 190, 460, 255, KEY_PLUS, "+1 MIN")
    c.send()


def show_running():
    global state, shown_secs
    state = RUNNING
    shown_secs = -1
    c = Cmd()
    c.delete_touch_areas()
    c.clear()
    c.text_color(COL_WHITE, COL_BLACK)
    c.font(FONT_TITLE)
    c.text("C", 240, 15, "COUNTING DOWN")
    c.send()

    c = Cmd()
    c.font(FONT_KEY)
    c.key(140, 190, 340, 255, KEY_CANCEL, "CANCEL")
    c.send()


def show_ringing():
    global state, ring_start
    state = RINGING
    ring_start = time.ticks_ms()
    c = Cmd()
    c.delete_touch_areas()
    c.clear()
    c.text_color(COL_RED, COL_BLACK)
    c.font(FONT_BIG)
    c.text("C", 240, 60, "WAKE UP!")
    c.text_color(COL_WHITE, COL_BLACK)
    c.font(FONT_KEY)
    c.key(40, 150, 440, 255, KEY_STOP, "STOP")
    c.send()


def handle_key(key):
    global set_minutes, end_at
    click_beep()
    if state == SETUP:
        if key == KEY_MINUS and set_minutes > 1:
            set_minutes -= 1
            draw_time(set_minutes * 60)
        elif key == KEY_PLUS and set_minutes < 99:
            set_minutes += 1
            draw_time(set_minutes * 60)
        elif key == KEY_START:
            end_at = time.ticks_add(time.ticks_ms(), set_minutes * 60000)
            show_running()
    elif state == RUNNING:
        if key == KEY_CANCEL:
            show_setup()
    elif state == RINGING:
        if key == KEY_STOP:
            buzzer(False)
            show_setup()


def main():
    global shown_secs
    time.sleep_ms(800)
    show_setup()
    print("Ready")

    last_poll = time.ticks_ms()
    while True:
        now = time.ticks_ms()

        if time.ticks_diff(now, last_poll) >= 50:
            last_poll = now
            key = poll_touch()
            if key:
                handle_key(key)

        if state == RUNNING:
            remaining = time.ticks_diff(end_at, now)
            if remaining <= 0:
                show_ringing()
            else:
                secs = (remaining + 999) // 1000
                if secs != shown_secs:
                    shown_secs = secs
                    draw_time(secs)

        elif state == RINGING:
            p = time.ticks_diff(now, ring_start) % 1000
            buzzer(p < 150 or 250 <= p < 400 or 500 <= p < 650)

        time.sleep_ms(5)


main()
